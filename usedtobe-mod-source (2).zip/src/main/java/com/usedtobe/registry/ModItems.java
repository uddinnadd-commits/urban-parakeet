package com.usedtobe.registry;

import com.usedtobe.UsedToBe;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, UsedToBe.MODID);

    public static final RegistryObject<Item> PARASITE_SPAWN_EGG = ITEMS.register("parasite_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.PARASITE, 0x5A1010, 0xD04050, new Item.Properties()));

    public static final RegistryObject<Item> ECHO_SPAWN_EGG = ITEMS.register("echo_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ECHO, 0x3E6B3A, 0xE0AC84, new Item.Properties()));

    private ModItems() {}
}
