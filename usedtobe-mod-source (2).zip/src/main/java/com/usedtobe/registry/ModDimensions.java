package com.usedtobe.registry;

import com.usedtobe.UsedToBe;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

public final class ModDimensions {
    public static final ResourceKey<Level> NOSTALGIA =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(UsedToBe.MODID, "nostalgia"));
    public static final ResourceKey<Level> BROKEN =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(UsedToBe.MODID, "brokenmemories"));

    private ModDimensions() {}
}
