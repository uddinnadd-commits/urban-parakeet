package com.usedtobe.registry;

import com.usedtobe.UsedToBe;
import com.usedtobe.entity.EchoEntity;
import com.usedtobe.entity.ParasiteEntity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = UsedToBe.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEvents {
    private ModEvents() {}

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.PARASITE.get(), ParasiteEntity.createAttributes().build());
        event.put(ModEntities.ECHO.get(), EchoEntity.createAttributes().build());
    }

    @SubscribeEvent
    public static void tabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
            ModItems.ITEMS.getEntries().forEach(item -> {
                if (item.get() instanceof BlockItem) {
                    event.accept(item.get());
                }
            });
        } else if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(ModItems.PARASITE_SPAWN_EGG.get());
            event.accept(ModItems.ECHO_SPAWN_EGG.get());
        }
    }
}
