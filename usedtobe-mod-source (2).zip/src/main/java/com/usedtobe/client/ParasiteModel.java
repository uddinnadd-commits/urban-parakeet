package com.usedtobe.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.usedtobe.UsedToBe;
import com.usedtobe.entity.ParasiteEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Original model: a segmented flesh worm with snapping mandibles, six scrabbling legs and a throbbing sac.
 * Texture is 64x64; every box's UVs are listed here and painted by tools/gen_assets.py (keep them in sync).
 */
public class ParasiteModel extends EntityModel<ParasiteEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(UsedToBe.MODID, "parasite"), "main");

    private static final String[] SEG_NAMES = {"seg1", "seg2", "seg3", "seg4", "tail"};

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart jawL;
    private final ModelPart jawR;
    private final ModelPart sac;
    private final ModelPart[] segs = new ModelPart[SEG_NAMES.length];
    private final ModelPart[] legsL = new ModelPart[3];
    private final ModelPart[] legsR = new ModelPart[3];

    public ParasiteModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.jawL = this.head.getChild("jaw_l");
        this.jawR = this.head.getChild("jaw_r");
        for (int i = 0; i < SEG_NAMES.length; i++) {
            this.segs[i] = root.getChild(SEG_NAMES[i]);
        }
        for (int i = 0; i < 3; i++) {
            this.legsL[i] = this.segs[i].getChild("leg_l");
            this.legsR[i] = this.segs[i].getChild("leg_r");
        }
        this.sac = this.segs[1].getChild("sac");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // origin of every body part sits on the ground (y=24) at its centre; the worm runs along +z, head at -z
        PartDefinition head = root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -7.0F, -3.5F, 8.0F, 7.0F, 7.0F),
                PartPose.offset(0.0F, 24.0F, -9.0F));
        head.addOrReplaceChild("jaw_l",
                CubeListBuilder.create().texOffs(32, 0).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 5.0F),
                PartPose.offset(2.2F, -2.5F, -3.5F));
        head.addOrReplaceChild("jaw_r",
                CubeListBuilder.create().texOffs(32, 8).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 5.0F),
                PartPose.offset(-2.2F, -2.5F, -3.5F));

        PartDefinition seg1 = root.addOrReplaceChild("seg1",
                CubeListBuilder.create().texOffs(0, 15).addBox(-5.0F, -9.0F, -4.0F, 10.0F, 9.0F, 8.0F),
                PartPose.offset(0.0F, 24.0F, -2.0F));
        PartDefinition seg2 = root.addOrReplaceChild("seg2",
                CubeListBuilder.create().texOffs(0, 32).addBox(-5.0F, -9.0F, -4.0F, 10.0F, 9.0F, 8.0F),
                PartPose.offset(0.0F, 24.0F, 6.0F));
        PartDefinition seg3 = root.addOrReplaceChild("seg3",
                CubeListBuilder.create().texOffs(0, 49).addBox(-4.0F, -7.0F, -3.5F, 8.0F, 7.0F, 7.0F),
                PartPose.offset(0.0F, 24.0F, 13.5F));
        root.addOrReplaceChild("seg4",
                CubeListBuilder.create().texOffs(36, 16).addBox(-3.0F, -5.0F, -3.0F, 6.0F, 5.0F, 6.0F),
                PartPose.offset(0.0F, 24.0F, 20.0F));
        root.addOrReplaceChild("tail",
                CubeListBuilder.create().texOffs(36, 28).addBox(-2.0F, -3.0F, -2.5F, 4.0F, 3.0F, 5.0F),
                PartPose.offset(0.0F, 24.0F, 25.5F));

        seg2.addOrReplaceChild("sac",
                CubeListBuilder.create().texOffs(36, 38).addBox(-3.0F, -3.0F, -3.0F, 6.0F, 3.0F, 6.0F),
                PartPose.offset(0.0F, -9.0F, 0.0F));

        CubeListBuilder leg = CubeListBuilder.create().texOffs(36, 48).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F);
        seg1.addOrReplaceChild("leg_l", leg, PartPose.offset(5.5F, -5.0F, 0.0F));
        seg1.addOrReplaceChild("leg_r", leg, PartPose.offset(-5.5F, -5.0F, 0.0F));
        seg2.addOrReplaceChild("leg_l", leg, PartPose.offset(5.5F, -5.0F, 0.0F));
        seg2.addOrReplaceChild("leg_r", leg, PartPose.offset(-5.5F, -5.0F, 0.0F));
        seg3.addOrReplaceChild("leg_l", leg, PartPose.offset(4.5F, -5.0F, 0.0F));
        seg3.addOrReplaceChild("leg_r", leg, PartPose.offset(-4.5F, -5.0F, 0.0F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(ParasiteEntity entity, float limbSwing, float limbSwingAmount, float age, float netHeadYaw, float headPitch) {
        float t = age * 0.2F;

        // body undulates like a worm
        this.head.x = Mth.sin(t) * 1.2F;
        this.head.yRot = Mth.sin(t) * 0.25F + netHeadYaw * ((float) Math.PI / 180.0F) * 0.5F;
        for (int i = 0; i < this.segs.length; i++) {
            float phase = t - (i + 1) * 0.8F;
            this.segs[i].x = Mth.sin(phase) * (1.5F + i * 0.5F);
            this.segs[i].yRot = Mth.sin(phase) * 0.2F;
        }

        // mandibles snap
        float open = 0.25F + 0.25F * Mth.sin(age * 0.35F);
        this.jawL.yRot = -open;
        this.jawR.yRot = open;

        // legs scrabble
        for (int i = 0; i < 3; i++) {
            float swing = Mth.sin(age * 0.7F + i * 1.1F) * 0.7F;
            this.legsL[i].xRot = swing;
            this.legsR[i].xRot = -swing;
        }

        // the sac throbs
        this.sac.y = -9.0F + Mth.sin(age * 0.26F) * 0.8F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
