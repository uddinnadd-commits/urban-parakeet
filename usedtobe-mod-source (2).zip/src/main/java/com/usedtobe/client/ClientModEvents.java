package com.usedtobe.client;

import com.usedtobe.UsedToBe;
import com.usedtobe.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = UsedToBe.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(ParasiteModel.LAYER, ParasiteModel::createBodyLayer);
        e.registerLayerDefinition(EchoModel.LAYER, EchoModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.PARASITE.get(), ParasiteRenderer::new);
        e.registerEntityRenderer(ModEntities.ECHO.get(), EchoRenderer::new);
    }
}
