package com.usedtobe.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.usedtobe.UsedToBe;
import com.usedtobe.entity.EchoEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Original model: a ten-year-old. Shorter and narrower than a player, big head, arms hanging.
 * Texture is 64x64; UVs here are painted by tools/gen_assets.py.
 */
public class EchoModel extends EntityModel<EchoEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(UsedToBe.MODID, "echo"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart armR;
    private final ModelPart armL;

    public EchoModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.armR = root.getChild("arm_r");
        this.armL = root.getChild("arm_l");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, 9.0F, 0.0F));
        root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(16, 16).addBox(-3.0F, 0.0F, -2.0F, 6.0F, 8.0F, 4.0F),
                PartPose.offset(0.0F, 9.0F, 0.0F));
        root.addOrReplaceChild("arm_r",
                CubeListBuilder.create().texOffs(40, 16).addBox(-1.5F, -0.5F, -1.5F, 3.0F, 8.0F, 3.0F),
                PartPose.offset(-4.5F, 9.5F, 0.0F));
        root.addOrReplaceChild("arm_l",
                CubeListBuilder.create().texOffs(40, 32).addBox(-1.5F, -0.5F, -1.5F, 3.0F, 8.0F, 3.0F),
                PartPose.offset(4.5F, 9.5F, 0.0F));
        root.addOrReplaceChild("leg_r",
                CubeListBuilder.create().texOffs(0, 16).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 7.0F, 3.0F),
                PartPose.offset(-1.5F, 17.0F, 0.0F));
        root.addOrReplaceChild("leg_l",
                CubeListBuilder.create().texOffs(0, 32).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 7.0F, 3.0F),
                PartPose.offset(1.5F, 17.0F, 0.0F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(EchoEntity entity, float limbSwing, float limbSwingAmount, float age, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180.0F);
        this.head.xRot = headPitch * ((float) Math.PI / 180.0F);
        // barely moves: just a slow sway of the hands
        this.armR.xRot = Mth.sin(age * 0.05F) * 0.05F;
        this.armL.xRot = -Mth.sin(age * 0.05F) * 0.05F;
        this.armR.zRot = 0.04F;
        this.armL.zRot = -0.04F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
