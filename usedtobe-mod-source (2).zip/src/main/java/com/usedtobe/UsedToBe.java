package com.usedtobe;

import com.mojang.logging.LogUtils;
import com.usedtobe.registry.ModBlocks;
import com.usedtobe.registry.ModEffects;
import com.usedtobe.registry.ModEntities;
import com.usedtobe.registry.ModFeatures;
import com.usedtobe.registry.ModItems;
import com.usedtobe.registry.ModSounds;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(UsedToBe.MODID)
public class UsedToBe {
    public static final String MODID = "usedtobe";
    public static final Logger LOGGER = LogUtils.getLogger();

    public UsedToBe() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModEffects.EFFECTS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModFeatures.FEATURES.register(bus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }
}
