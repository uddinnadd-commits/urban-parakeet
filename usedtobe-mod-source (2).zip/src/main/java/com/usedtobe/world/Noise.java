package com.usedtobe.world;

/**
 * Small deterministic noise helpers. Deliberately free of Minecraft types so the shape of the worlds
 * (Terrain, MazeShape) can be unit-tested and previewed outside the game.
 */
public final class Noise {
    private Noise() {}

    public static long mix(long seed, int x, int y, int z) {
        long h = seed ^ (x * 0x9E3779B97F4A7C15L) ^ (y * 0xC2B2AE3D27D4EB4FL) ^ (z * 0x165667B19E3779F9L);
        h ^= h >>> 33;
        h *= 0xff51afd7ed558ccdL;
        h ^= h >>> 33;
        h *= 0xc4ceb9fe1a85ec53L;
        h ^= h >>> 33;
        return h;
    }

    /** Hash to [0, 1). */
    public static double unit(long seed, int x, int z) {
        return (mix(seed, x, 0, z) >>> 11) * (1.0D / (1L << 53));
    }

    public static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    public static double smoothstep(double a, double b, double x) {
        double t = Math.max(0.0D, Math.min(1.0D, (x - a) / (b - a)));
        return t * t * (3.0D - 2.0D * t);
    }

    private static double fade(double t) {
        return t * t * t * (t * (t * 6.0D - 15.0D) + 10.0D);
    }

    private static double lattice(long seed, int x, int z) {
        return unit(seed, x, z) * 2.0D - 1.0D;
    }

    /** Smooth value noise, roughly in [-1, 1]. */
    public static double value(long seed, double x, double z) {
        int x0 = (int) Math.floor(x);
        int z0 = (int) Math.floor(z);
        double u = fade(x - x0);
        double v = fade(z - z0);
        double a = lattice(seed, x0, z0);
        double b = lattice(seed, x0 + 1, z0);
        double c = lattice(seed, x0, z0 + 1);
        double d = lattice(seed, x0 + 1, z0 + 1);
        return lerp(lerp(a, b, u), lerp(c, d, u), v);
    }

    /** Fractal sum of value noise, normalised back to roughly [-1, 1]. */
    public static double fbm(long seed, double x, double z, int octaves) {
        double sum = 0.0D;
        double amp = 1.0D;
        double norm = 0.0D;
        double f = 1.0D;
        for (int i = 0; i < octaves; i++) {
            sum += value(seed + i * 1013L, x * f, z * f) * amp;
            norm += amp;
            amp *= 0.5D;
            f *= 2.0D;
        }
        return sum / norm;
    }
}
