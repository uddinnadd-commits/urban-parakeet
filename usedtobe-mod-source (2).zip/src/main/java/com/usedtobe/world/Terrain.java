package com.usedtobe.world;

/**
 * The shape of the nostalgia world. Everything here is a pure function of (seed, x, z), so the terrain feature,
 * the base builders and the story director always agree about where the ground is.
 *
 * Open meadows are dead flat at BASE (that is where the old bases live and where notebooks get dropped);
 * between them the land rolls into terraced hills, tarns and winding worn paths.
 */
public final class Terrain {
    /** y of the grass layer on flat ground (first air block above is 64). */
    public static final int BASE = 63;
    /** top y of any pond water. */
    public static final int WATER_Y = 62;
    public static final int SPAWN_X = 8;
    public static final int SPAWN_Z = 8;

    private static final long S_HILL = 0x5EED0001L;
    private static final long S_BUMP = 0x5EED0002L;
    private static final long S_MASK = 0x5EED0003L;
    private static final long S_LAKE = 0x5EED0004L;
    private static final long S_PATH = 0x5EED0005L;
    private static final long S_FOREST = 0x5EED0006L;
    private static final long S_BASE = 0x5EED0007L;
    private static final long S_TERRACE = 0x5EED0008L;

    private Terrain() {}

    /** y of the top solid block of the column. */
    public static int height(long seed, int x, int z) {
        double dx = x - SPAWN_X;
        double dz = z - SPAWN_Z;
        double near = Noise.smoothstep(30.0D, 90.0D, Math.sqrt(dx * dx + dz * dz)); // 0 at your first house

        double country = Noise.smoothstep(0.04D, 0.30D, Noise.fbm(seed ^ S_MASK, x * 0.0058D, z * 0.0058D, 3));
        double hills = Noise.fbm(seed ^ S_HILL, x * 0.0105D, z * 0.0105D, 4) + 0.10D;
        double bumps = Noise.fbm(seed ^ S_BUMP, x * 0.055D, z * 0.055D, 2);

        double rel = hills >= 0.0D ? hills * 44.0D : hills * 6.0D;     // hills climb, valleys only dip a little
        if (rel > 0.0D) {
            double terraced = Noise.fbm(seed ^ S_TERRACE, x * 0.01D, z * 0.01D, 2);
            double t = rel / 4.0D;
            double f = Math.floor(t);
            double stepped = (f + Noise.smoothstep(0.30D, 0.70D, t - f)) * 4.0D; // flat shelves with short cliffs
            rel = Noise.lerp(rel, stepped, 0.45D + 0.4D * Noise.smoothstep(-0.2D, 0.4D, terraced));
        }
        double h = BASE + country * near * (rel + bumps * 3.2D);

        double lake = Noise.fbm(seed ^ S_LAKE, x * 0.017D, z * 0.017D, 3);
        double li = Noise.smoothstep(0.34D, 0.54D, lake) * near * (1.0D - 0.75D * country);
        h = Noise.lerp(h, 56.5D, li);

        return (int) Math.max(52, Math.min(96, Math.round(h)));
    }

    public static boolean isWater(int h) {
        return h < WATER_Y;
    }

    /** Thin winding trails of worn ground, wherever somebody used to walk. */
    public static boolean isPath(long seed, int x, int z) {
        return Math.abs(Noise.fbm(seed ^ S_PATH, x * 0.021D, z * 0.021D, 2)) < 0.016D;
    }

    /** 0..1 how thickly the trees stand here. */
    public static double forest(long seed, int x, int z) {
        double f = Noise.fbm(seed ^ S_FOREST, x * 0.024D, z * 0.024D, 2);
        return Noise.smoothstep(-0.05D, 0.35D, f);
    }

    /** Decides, per chunk, whether the chunk holds one of the old bases (otherwise it may get trees and props). */
    public static boolean baseChunk(long seed, int chunkX, int chunkZ) {
        return Noise.unit(seed ^ S_BASE, chunkX, chunkZ) < 0.20D;
    }

    /** True if every sampled column in the rectangle (inclusive) is exactly flat ground. */
    public static boolean isFlat(long seed, int x1, int z1, int x2, int z2) {
        for (int x = x1; x <= x2; x += 2) {
            for (int z = z1; z <= z2; z += 2) {
                if (height(seed, x, z) != BASE) {
                    return false;
                }
            }
        }
        return height(seed, x2, z2) == BASE && height(seed, x1, z2) == BASE && height(seed, x2, z1) == BASE;
    }

    /** How lumpy a rectangle is: height range, plus a big penalty for water. 0 = perfect building plot. */
    public static int roughness(long seed, int x1, int z1, int x2, int z2) {
        int lo = Integer.MAX_VALUE;
        int hi = Integer.MIN_VALUE;
        int penalty = 0;
        for (int x = x1; x <= x2; x += 2) {
            for (int z = z1; z <= z2; z += 2) {
                int h = height(seed, x, z);
                lo = Math.min(lo, h);
                hi = Math.max(hi, h);
                if (isWater(h)) {
                    penalty += 40;
                }
            }
        }
        return hi - lo + penalty;
    }
}
