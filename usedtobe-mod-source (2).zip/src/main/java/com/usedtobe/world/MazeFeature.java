package com.usedtobe.world;

import com.usedtobe.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BedPart;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Builds brokenmemories one chunk at a time from the pure layout in MazeShape: the flesh maze, the pillared halls
 * and the ruined-house archives. All the decisions live in MazeShape; this class only turns them into blocks.
 */
public class MazeFeature extends Feature<NoneFeatureConfiguration> {
    public static final int CELL = MazeShape.CELL;
    public static final int FLOOR = MazeShape.FLOOR;   // top block of the flat-world layers
    public static final int HEIGHT = 5;                // typical open air above the floor
    public static final int TOP = MazeShape.TOP;       // everything above the ceiling is solid up to here

    public MazeFeature() {
        super(NoneFeatureConfiguration.CODEC);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        long seed = level.getSeed();
        BlockPos origin = ctx.origin();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = origin.getX() + lx;
                int z = origin.getZ() + lz;
                int zone = MazeShape.zoneAt(seed, x, z);
                int ceil = MazeShape.ceilingY(seed, x, z);

                if (!MazeShape.isOpen(seed, x, z)) {
                    for (int y = FLOOR + 1; y <= TOP; y++) {
                        level.setBlock(pos.set(x, y, z), wallBlock(MazeShape.wall(seed, x, y, z, zone)), 2);
                    }
                    continue;
                }

                level.setBlock(pos.set(x, FLOOR, z), floorBlock(seed, x, z, zone), 2);

                // everything from the ceiling up to the roof of the world is solid, so nothing leaks into the void
                for (int y = ceil; y <= TOP; y++) {
                    level.setBlock(pos.set(x, y, z), ceilingBlock(seed, x, y, z, ceil, zone), 2);
                }

                for (int y = FLOOR + 1; y <= FLOOR + 3; y++) {
                    int code = MazeShape.prop(seed, x, y, z, zone);
                    if (code != MazeShape.PROP_NONE) {
                        level.setBlock(pos.set(x, y, z), propBlock(code), 2);
                    }
                }

                int hang = MazeShape.hangLength(seed, x, z, zone);
                for (int k = 0; k < hang; k++) {
                    int y = ceil - 1 - k;
                    if (y <= FLOOR + 2) {
                        break;
                    }
                    level.setBlock(pos.set(x, y, z),
                            k == hang - 1 ? ModBlocks.FLESH_GLOW.get().defaultBlockState()
                                    : ModBlocks.SINEW.get().defaultBlockState(), 2);
                }
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ block palettes

    private static BlockState floorBlock(long seed, int x, int z, int zone) {
        if (zone == MazeShape.ZONE_ARCHIVE) {
            return Math.floorMod(Noise.mix(seed, x, 77, z), 9L) == 0L
                    ? ModBlocks.FLESH_FLOOR.get().defaultBlockState()
                    : ModBlocks.OLD_PLANKS.get().defaultBlockState();
        }
        if (MazeShape.isScar(seed, x, z, zone)) {
            return ModBlocks.SCAR_TISSUE.get().defaultBlockState();
        }
        if (zone == MazeShape.ZONE_VEINS && Math.floorMod(Noise.mix(seed, x, FLOOR, z), 53L) == 0L) {
            return ModBlocks.OLD_GRASS.get().defaultBlockState(); // a rare patch of grass someone remembers
        }
        return ModBlocks.FLESH_FLOOR.get().defaultBlockState();
    }

    private static BlockState ceilingBlock(long seed, int x, int y, int z, int ceil, int zone) {
        int r = (int) Math.floorMod(Noise.mix(seed, x, y, z), 100L);
        if (y == ceil) {
            if (zone == MazeShape.ZONE_ARCHIVE) {
                return r < 6 ? Blocks.SHROOMLIGHT.defaultBlockState() : ModBlocks.OLD_PLANKS.get().defaultBlockState();
            }
            if (r < (zone == MazeShape.ZONE_HALL ? 7 : 3)) {
                return ModBlocks.FLESH_GLOW.get().defaultBlockState();
            }
        }
        return ModBlocks.FLESH.get().defaultBlockState();
    }

    private static BlockState wallBlock(int code) {
        return switch (code) {
            case MazeShape.WALL_GLOW -> ModBlocks.FLESH_GLOW.get().defaultBlockState();
            case MazeShape.WALL_PLANKS -> ModBlocks.OLD_PLANKS.get().defaultBlockState();
            case MazeShape.WALL_COBBLE -> ModBlocks.OLD_COBBLE.get().defaultBlockState();
            case MazeShape.WALL_DIRT -> ModBlocks.OLD_DIRT.get().defaultBlockState();
            case MazeShape.WALL_SINEW -> ModBlocks.SINEW.get().defaultBlockState();
            case MazeShape.WALL_SHELF -> Blocks.BOOKSHELF.defaultBlockState();
            case MazeShape.WALL_SHROOM -> Blocks.SHROOMLIGHT.defaultBlockState();
            case MazeShape.WALL_SCAR -> ModBlocks.SCAR_TISSUE.get().defaultBlockState();
            default -> ModBlocks.FLESH.get().defaultBlockState();
        };
    }

    private static BlockState propBlock(int code) {
        return switch (code) {
            case MazeShape.PROP_GLOW -> ModBlocks.FLESH_GLOW.get().defaultBlockState();
            case MazeShape.PROP_BONE -> Blocks.BONE_BLOCK.defaultBlockState();
            case MazeShape.PROP_TUMOR -> ModBlocks.SCAR_TISSUE.get().defaultBlockState();
            case MazeShape.PROP_BED_FOOT -> Blocks.RED_BED.defaultBlockState()
                    .setValue(BedBlock.FACING, Direction.SOUTH).setValue(BedBlock.PART, BedPart.FOOT);
            case MazeShape.PROP_BED_HEAD -> Blocks.RED_BED.defaultBlockState()
                    .setValue(BedBlock.FACING, Direction.SOUTH).setValue(BedBlock.PART, BedPart.HEAD);
            case MazeShape.PROP_SHELF -> Blocks.BOOKSHELF.defaultBlockState();
            case MazeShape.PROP_TABLE_LEG -> Blocks.OAK_FENCE.defaultBlockState();
            case MazeShape.PROP_TABLE_TOP -> Blocks.OAK_PRESSURE_PLATE.defaultBlockState();
            case MazeShape.PROP_TORCH -> Blocks.TORCH.defaultBlockState();
            default -> Blocks.AIR.defaultBlockState();
        };
    }
}
