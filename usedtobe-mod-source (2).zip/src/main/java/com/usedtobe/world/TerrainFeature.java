package com.usedtobe.world;

import com.usedtobe.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.SlabType;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Sculpts the nostalgia world one chunk at a time on top of the flat base layers: meadows, terraced hills, tarns with
 * sandy shores, worn paths, tall grass and wildflowers, groves, and the odd leftover from a childhood
 * (swings, a sandbox, a fire ring, a bench). The shape itself comes from Terrain, so every other system agrees on it.
 * Only the columns of this chunk are written, so generation order never matters.
 */
public class TerrainFeature extends Feature<NoneFeatureConfiguration> {
    private static final long S_COVER = 0x7E44A001L;
    private static final long S_KIND = 0x7E44A002L;
    private static final long S_PATCH = 0x7E44A003L;

    public TerrainFeature() {
        super(NoneFeatureConfiguration.CODEC);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        RandomSource r = ctx.random();
        long seed = level.getSeed();
        int x0 = ctx.origin().getX();
        int z0 = ctx.origin().getZ();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        BlockState air = Blocks.AIR.defaultBlockState();
        BlockState grass = ModBlocks.OLD_GRASS.get().defaultBlockState();
        BlockState dirt = ModBlocks.OLD_DIRT.get().defaultBlockState();
        BlockState stone = ModBlocks.OLD_STONE.get().defaultBlockState();
        BlockState path = ModBlocks.OLD_PATH.get().defaultBlockState();
        BlockState water = Blocks.WATER.defaultBlockState();

        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = x0 + lx;
                int z = z0 + lz;
                int h = Terrain.height(seed, x, z);

                if (h > Terrain.BASE) {
                    for (int y = Terrain.BASE; y < h; y++) {
                        level.setBlock(pos.set(x, y, z), y >= h - 3 ? dirt : stone, 2);
                    }
                } else if (h < Terrain.BASE) {
                    for (int y = Terrain.BASE; y > h; y--) {
                        level.setBlock(pos.set(x, y, z), air, 2);
                    }
                    for (int y = h - 1; y >= h - 3; y--) {
                        level.setBlock(pos.set(x, y, z), dirt, 2);
                    }
                }

                if (Terrain.isWater(h)) {
                    BlockState bed = h >= Terrain.WATER_Y - 2 ? Blocks.SAND.defaultBlockState()
                            : h <= 57 ? Blocks.GRAVEL.defaultBlockState() : dirt;
                    level.setBlock(pos.set(x, h, z), bed, 2);
                    for (int y = h + 1; y <= Terrain.WATER_Y; y++) {
                        level.setBlock(pos.set(x, y, z), water, 2);
                    }
                    continue;
                }

                boolean onPath = Terrain.isPath(seed, x, z);
                level.setBlock(pos.set(x, h, z), onPath ? path : grass, 2);
                if (!onPath) {
                    cover(level, pos, seed, x, h, z);
                }
            }
        }

        int cx = x0 >> 4;
        int cz = z0 >> 4;
        boolean baseChunk = Terrain.baseChunk(seed, cx, cz);
        boolean nearSpawn = Math.abs(x0 - Terrain.SPAWN_X) < 48 && Math.abs(z0 - Terrain.SPAWN_Z) < 48;

        if (!baseChunk && !nearSpawn) {
            groves(level, r, seed, x0, z0);
            if (r.nextInt(12) == 0) {
                landmark(level, r, seed, x0, z0);
            }
            if (r.nextInt(34) == 0) {
                bigTree(level, r, seed, x0 + 6 + r.nextInt(4), z0 + 6 + r.nextInt(4));
            }
        } else if (!baseChunk) {
            // close to your first house: a few friendly trees only
            if (r.nextInt(3) == 0) {
                int x = x0 + 2 + r.nextInt(12);
                int z = z0 + 2 + r.nextInt(12);
                int h = Terrain.height(seed, x, z);
                if (h == Terrain.BASE && Math.abs(x - Terrain.SPAWN_X) + Math.abs(z - Terrain.SPAWN_Z) > 22) {
                    NostalgiaFeature.tree(level, r, x, h + 1, z);
                }
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ ground cover

    private static void cover(WorldGenLevel level, BlockPos.MutableBlockPos pos, long seed, int x, int h, int z) {
        double u = Noise.unit(seed ^ S_COVER, x, z);
        double patch = Noise.value(seed ^ S_PATCH, x * 0.11D, z * 0.11D);
        double flowerChance = 0.16D * Noise.smoothstep(0.30D, 0.70D, patch);
        double grassChance = 0.10D + 0.16D * Noise.smoothstep(-0.1D, 0.5D, patch);
        if (u >= grassChance + flowerChance) {
            return;
        }
        if (!level.getBlockState(pos.set(x, h + 1, z)).isAir()) {
            return;
        }
        BlockState plant;
        if (u < flowerChance) {
            int k = (int) (Noise.unit(seed ^ S_KIND, x, z) * 100.0D);
            plant = k < 38 ? Blocks.DANDELION.defaultBlockState()
                    : k < 62 ? Blocks.POPPY.defaultBlockState()
                    : k < 80 ? Blocks.OXEYE_DAISY.defaultBlockState()
                    : k < 92 ? Blocks.AZURE_BLUET.defaultBlockState()
                    : Blocks.CORNFLOWER.defaultBlockState();
        } else {
            plant = Noise.unit(seed ^ S_KIND, x + 7, z) < 0.12D ? Blocks.FERN.defaultBlockState() : Blocks.GRASS.defaultBlockState();
        }
        level.setBlock(pos.set(x, h + 1, z), plant, 2);
    }

    // ------------------------------------------------------------------ trees

    private static void groves(WorldGenLevel level, RandomSource r, long seed, int x0, int z0) {
        int tries = 3 + r.nextInt(5);
        for (int i = 0; i < tries; i++) {
            int x = x0 + 2 + r.nextInt(12);
            int z = z0 + 2 + r.nextInt(12);
            int h = Terrain.height(seed, x, z);
            if (h < Terrain.WATER_Y || Terrain.isPath(seed, x, z)) {
                continue;
            }
            double density = Terrain.forest(seed, x, z);
            if (r.nextDouble() < 0.10D + 0.85D * density) {
                NostalgiaFeature.tree(level, r, x, h + 1, z);
            }
        }
    }

    /** A big old tree you could climb: 2x2 trunk, wide crown. Needs flat ground. */
    private static void bigTree(WorldGenLevel level, RandomSource r, long seed, int x, int z) {
        if (!Terrain.isFlat(seed, x - 1, z - 1, x + 2, z + 2)) {
            return;
        }
        int base = Terrain.BASE + 1;
        int h = 11 + r.nextInt(4);
        BlockState log = ModBlocks.OLD_LOG.get().defaultBlockState();
        BlockState leaves = ModBlocks.OLD_LEAVES.get().defaultBlockState();
        for (int dy = h - 6; dy <= h + 1; dy++) {
            double rad = dy >= h ? 2.2D : dy >= h - 1 ? 4.0D : dy >= h - 4 ? 5.0D : 4.2D;
            for (int dx = -5; dx <= 6; dx++) {
                for (int dz = -5; dz <= 6; dz++) {
                    double ex = dx - 0.5D;
                    double ez = dz - 0.5D;
                    if (ex * ex + ez * ez > rad * rad || r.nextInt(7) == 0) {
                        continue;
                    }
                    BlockPos p = new BlockPos(x + dx, base + dy, z + dz);
                    if (level.getBlockState(p).isAir()) {
                        level.setBlock(p, leaves, 2);
                    }
                }
            }
        }
        for (int dx = 0; dx <= 1; dx++) {
            for (int dz = 0; dz <= 1; dz++) {
                for (int dy = 0; dy < h; dy++) {
                    level.setBlock(new BlockPos(x + dx, base + dy, z + dz), log, 2);
                }
            }
        }
    }

    // ------------------------------------------------------------------ things left behind

    private static void landmark(WorldGenLevel level, RandomSource r, long seed, int x0, int z0) {
        int kind = r.nextInt(4);
        int[] size = kind == 0 ? new int[] {5, 3} : kind == 1 ? new int[] {5, 5} : kind == 2 ? new int[] {7, 7} : new int[] {3, 1};
        int x = x0 + 2 + r.nextInt(12 - size[0]);
        int z = z0 + 2 + r.nextInt(12 - size[1]);
        if (!Terrain.isFlat(seed, x - 1, z - 1, x + size[0], z + size[1])) {
            return;
        }
        switch (kind) {
            case 0 -> swingSet(level, x, z);
            case 1 -> sandbox(level, x, z);
            case 2 -> fireRing(level, x, z);
            default -> bench(level, x, z);
        }
    }

    private static void swingSet(LevelAccessor l, int x, int z) {
        int y = Terrain.BASE + 1;
        BlockState fence = Blocks.OAK_FENCE.defaultBlockState();
        for (int dy = 0; dy < 3; dy++) {
            set(l, x, y + dy, z, fence);
            set(l, x + 4, y + dy, z, fence);
            set(l, x, y + dy, z + 2, fence);
            set(l, x + 4, y + dy, z + 2, fence);
        }
        BlockState beam = ModBlocks.OLD_LOG.get().defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.X);
        for (int dx = 0; dx <= 4; dx++) {
            set(l, x + dx, y + 3, z + 1, beam);
        }
        set(l, x, y + 3, z, beam);
        set(l, x, y + 3, z + 2, beam);
        set(l, x + 4, y + 3, z, beam);
        set(l, x + 4, y + 3, z + 2, beam);
        BlockState chain = Blocks.CHAIN.defaultBlockState();
        BlockState seat = Blocks.OAK_SLAB.defaultBlockState().setValue(SlabBlock.TYPE, SlabType.BOTTOM);
        for (int sx : new int[] {x + 1, x + 3}) {
            set(l, sx, y + 2, z + 1, chain);
            set(l, sx, y + 1, z + 1, chain);
            set(l, sx, y, z + 1, seat);
        }
    }

    private static void sandbox(LevelAccessor l, int x, int z) {
        int y = Terrain.BASE;
        BlockState plank = ModBlocks.OLD_PLANKS.get().defaultBlockState();
        for (int dx = 0; dx < 5; dx++) {
            for (int dz = 0; dz < 5; dz++) {
                boolean edge = dx == 0 || dz == 0 || dx == 4 || dz == 4;
                if (edge) {
                    set(l, x + dx, y + 1, z + dz, plank);
                } else {
                    set(l, x + dx, y, z + dz, Blocks.SAND.defaultBlockState());
                }
            }
        }
        set(l, x + 3, y + 1, z + 3, Blocks.CAULDRON.defaultBlockState()); // somebody's bucket
    }

    private static void fireRing(LevelAccessor l, int x, int z) {
        int y = Terrain.BASE + 1;
        int c = 3;
        BlockState stone = ModBlocks.OLD_COBBLE.get().defaultBlockState();
        int[][] ring = {{-2, 0}, {2, 0}, {0, -2}, {0, 2}, {-1, -2}, {1, -2}, {-1, 2}, {1, 2}, {-2, -1}, {-2, 1}, {2, -1}, {2, 1}};
        for (int[] o : ring) {
            set(l, x + c + o[0], y, z + c + o[1], stone);
        }
        set(l, x + c, y, z + c, Blocks.CAMPFIRE.defaultBlockState().setValue(BlockStateProperties.LIT, false));
        BlockState logX = ModBlocks.OLD_LOG.get().defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.X);
        BlockState logZ = ModBlocks.OLD_LOG.get().defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.Z);
        set(l, x + c - 1, y, z, logX);
        set(l, x + c, y, z, logX);
        set(l, x + c - 1, y, z + 6, logX);
        set(l, x + c, y, z + 6, logX);
        set(l, x, y, z + c, logZ);
        set(l, x + 6, y, z + c, logZ);
    }

    private static void bench(LevelAccessor l, int x, int z) {
        int y = Terrain.BASE + 1;
        BlockState stairs = Blocks.OAK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.SOUTH);
        for (int dx = 0; dx < 3; dx++) {
            set(l, x + dx, y, z, stairs);
        }
    }

    private static void set(LevelAccessor l, int x, int y, int z, BlockState s) {
        l.setBlock(new BlockPos(x, y, z), s, 2);
    }
}
