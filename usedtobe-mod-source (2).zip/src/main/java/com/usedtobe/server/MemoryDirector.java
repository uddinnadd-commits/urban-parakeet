package com.usedtobe.server;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.usedtobe.Config;
import com.usedtobe.UsedToBe;
import com.usedtobe.entity.EchoEntity;
import com.usedtobe.entity.ParasiteEntity;
import com.usedtobe.registry.ModBlocks;
import com.usedtobe.registry.ModDimensions;
import com.usedtobe.registry.ModEffects;
import com.usedtobe.registry.ModEntities;
import com.usedtobe.registry.ModSounds;
import com.usedtobe.world.MazeFeature;
import com.usedtobe.world.NostalgiaFeature;
import com.usedtobe.world.MazeShape;
import com.usedtobe.world.Terrain;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

/**
 * The script. Per player, in their persistent data.
 *
 * Act 1 (nostalgia): find the ten-year-old's notebooks (Book and Quills tagged usedtobe_memory). Each one you
 * carry advances the decay, and the world drops the next base somewhere out in the fog and points a compass at it.
 * Find enough (or run out the fallback timer) and the ground gives way.
 *
 * Act 2 (brokenmemories): touch the hearts hidden in the maze. Parasites get worse with each. Touch the last one
 * and you wake up.
 */
@Mod.EventBusSubscriber(modid = UsedToBe.MODID)
public final class MemoryDirector {
    public static final int PHASE_START = 0;
    public static final int PHASE_NOSTALGIA = 1;
    public static final int PHASE_BROKEN = 2;
    public static final int PHASE_DONE = 3; // after the ending or /usedtobe reset: no auto-enter

    private static final String ROOT = "usedtobe";
    /** Fraction of progress at which stages 0..4 begin. */
    private static final double[] STAGE_START = {0.0D, 0.22D, 0.45D, 0.65D, 0.85D};
    private static final int SPAWN_X = 10;
    private static final int SPAWN_Z = 5;

    private static final int CHAPTER_COUNT = 5;
    private static final String[] CHAPTER = {"", "the fading", "the forgetting", "the unbuilding", "the last of it"};
    private static final String[] CHAPTER_SUB = {
            "", "it's quieter than you remember", "you can't picture your own face then",
            "it's coming apart because you stopped looking", "hold on to what you can"
    };
    /** Heart n (1-based) lives in this kind of place: the maze first, then stranger and stranger rooms. */
    private static final int[] HEART_ZONES = {
            MazeShape.ZONE_VEINS, MazeShape.ZONE_ARCHIVE, MazeShape.ZONE_HALL, MazeShape.ZONE_ARCHIVE, MazeShape.ZONE_HALL,
            MazeShape.ZONE_HALL, MazeShape.ZONE_ARCHIVE, MazeShape.ZONE_HALL
    };
    private static final String[] HEART_LINES = {
            "it let go. the walls noticed.",
            "it's still holding the rest.",
            "it knows your name now.",
            "you're taking it back. it won't forgive you.",
            "keep going. it's almost yours again."
    };

    private static final List<Runnable> DEFERRED = new ArrayList<>();
    private static final List<Crack> CRACKS = new ArrayList<>();

    private static final String[] STAGE1 = {
            "you'll never get this back, you know?",
            "it's exactly how you left it.",
            "you wrote everything down. you always did.",
            "i kept everything. all of it.",
            "you used to stay until it got dark.",
            "listen. it's quiet. it was always this quiet.",
            "this was enough, once."
    };
    private static final String[] STAGE2 = {
            "why did you stop coming back?",
            "you grew up. i didn't.",
            "i can't remember the way you looked then.",
            "stay a little longer. just a little.",
            "it was better before, wasn't it?",
            "you built that. you were so proud of it.",
            "you'll never get this back, you know?"
    };
    private static final String[] STAGE3 = {
            "it's coming apart because you stopped looking.",
            "<<left>>",
            "i can't hold all of it.",
            "that was your house. that was you.",
            "don't leave. you already did.",
            "everything you loved here is dying, {name}.",
            "<<left>>"
    };
    private static final String[] STAGE4 = {
            "you can't take any of it with you.",
            "look what you let happen.",
            "i'm forgetting the colours.",
            "it's all going, {name}.",
            "you'll never get this back.",
            "<<left>>"
    };
    private static final String[] FOUND = {
            "yes. that one. keep going.",
            "you remember it now, don't you.",
            "there's more. there's always more.",
            "i forgot i wrote that.",
            "you were so serious about it."
    };
    private static final String[] BROKEN = {
            "you should have visited more.",
            "it grew where you stopped caring.",
            "can you hear it? it's your heartbeat now.",
            "every memory you abandoned is hungry.",
            "they're still breathing, {name}.",
            "it hurts to be remembered like this.",
            "you can't wake up from something you let in.",
            "don't stop moving. it's learning your steps.",
            "it was beautiful once. you left it alone with this."
    };
    private static final String[] HEARTS = {
            "it let go.",
            "it's still holding the rest.",
            "you're taking it back. it won't forgive you.",
            "keep going. it's almost yours again."
    };

    private MemoryDirector() {}

    // ================================================================ state

    public static CompoundTag data(Player p) {
        CompoundTag forge = p.getPersistentData();
        if (!forge.contains(Player.PERSISTED_NBT_TAG, Tag.TAG_COMPOUND)) {
            forge.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        }
        CompoundTag persisted = forge.getCompound(Player.PERSISTED_NBT_TAG);
        if (!persisted.contains(ROOT, Tag.TAG_COMPOUND)) {
            persisted.put(ROOT, new CompoundTag());
        }
        return persisted.getCompound(ROOT);
    }

    private static void wipe(CompoundTag d) {
        for (String key : new ArrayList<>(d.getAllKeys())) {
            d.remove(key);
        }
    }

    private static void defer(Runnable r) {
        DEFERRED.add(r);
    }

    // ================================================================ events

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && data(p).getInt("phase") == PHASE_START && Config.AUTO_ENTER.get()) {
            defer(() -> beginNostalgia(p));
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        data(e.getEntity()).merge(data(e.getOriginal()));
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) {
            return;
        }
        if (!DEFERRED.isEmpty()) {
            List<Runnable> copy = new ArrayList<>(DEFERRED);
            DEFERRED.clear();
            copy.forEach(Runnable::run);
        }
        if (!CRACKS.isEmpty()) {
            Iterator<Crack> it = CRACKS.iterator();
            while (it.hasNext()) {
                if (!it.next().tick()) {
                    it.remove();
                }
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER || !(e.player instanceof ServerPlayer p)) {
            return;
        }
        CompoundTag d = data(p);
        switch (d.getInt("phase")) {
            case PHASE_NOSTALGIA -> tickNostalgia(p, d);
            case PHASE_BROKEN -> tickBroken(p, d);
            default -> { }
        }
    }

    @SubscribeEvent
    public static void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("usedtobe")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("start").executes(c -> {
                    beginNostalgia(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("status").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    CompoundTag d = data(p);
                    String text = "phase " + d.getInt("phase")
                            + " | notebooks " + d.getInt("foundCount") + "/" + Config.MEMORIES_REQUIRED.get()
                            + " | hearts " + d.getInt("hearts") + "/" + Config.HEARTS_REQUIRED.get()
                            + " | chapter " + d.getInt("stageShown");
                    c.getSource().sendSuccess(() -> Component.literal("usedtobe: " + text), false);
                    return 1;
                }))
                .then(Commands.literal("remember").executes(c -> {
                    rememberNext(c.getSource().getPlayerOrException());
                    return 1;
                }))
                .then(Commands.literal("heart").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    CompoundTag d = data(p);
                    if (d.getInt("phase") == PHASE_BROKEN && d.contains("heartX")) {
                        onHeartTouched(p, new BlockPos(d.getInt("heartX"), MazeFeature.FLOOR + 1, d.getInt("heartZ")));
                    }
                    return 1;
                }))
                .then(Commands.literal("stage")
                        .then(Commands.argument("n", IntegerArgumentType.integer(0, 4)).executes(c -> {
                            ServerPlayer p = c.getSource().getPlayerOrException();
                            if (data(p).getInt("phase") != PHASE_NOSTALGIA) {
                                beginNostalgia(p);
                            }
                            int n = IntegerArgumentType.getInteger(c, "n");
                            data(p).putInt("forceStage", n);
                            c.getSource().sendSuccess(() -> Component.literal("usedtobe: stage " + n), false);
                            return 1;
                        })))
                .then(Commands.literal("site").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    if (data(p).getInt("phase") == PHASE_NOSTALGIA) {
                        data(p).putInt("sitePending", 1);
                    }
                    return 1;
                }))
                .then(Commands.literal("collapse").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    if (data(p).getInt("phase") != PHASE_NOSTALGIA) {
                        beginNostalgia(p);
                    }
                    data(p).putInt("ticks", Config.COLLAPSE_MINUTES.get() * 1200);
                    return 1;
                }))
                .then(Commands.literal("broken").executes(c -> {
                    enterBroken(c.getSource().getPlayerOrException(), false);
                    return 1;
                }))
                .then(Commands.literal("reset").executes(c -> {
                    reset(c.getSource().getPlayerOrException());
                    return 1;
                })));
    }

    // ================================================================ phase changes

    public static void beginNostalgia(ServerPlayer p) {
        MinecraftServer server = p.server;
        ServerLevel level = server.getLevel(ModDimensions.NOSTALGIA);
        if (level == null) {
            p.sendSystemMessage(Component.literal("[usedtobe] the nostalgia dimension isn't loaded (is the mod's data pack enabled?)"));
            return;
        }
        CompoundTag d = data(p);
        wipe(d);
        d.putInt("phase", PHASE_NOSTALGIA);
        d.putInt("nextMsg", 900);
        d.putLong("dayT", 6000L);
        d.putInt("stageShown", 0);
        d.put("found", new CompoundTag());

        lockRules(server);
        server.overworld().setDayTime(6000L);

        // your first house, right where you spawn - its chest holds the first notebook
        NostalgiaFeature.clearArea(level, 5, 3, 15, 14);
        NostalgiaFeature.dirtHut(level, RandomSource.create(1234L), 8, 8, NostalgiaFeature.lootId("book_first"));

        removeCompass(p);
        p.removeEffect(ModEffects.THE_ROT.get());
        p.teleportTo(level, SPAWN_X + 0.5D, 64.0D, SPAWN_Z + 0.5D, 0.0F, 0.0F);
        p.fallDistance = 0.0F;
        titles(p, "usedtobe", "it's exactly how you left it");
    }

    private static void returnToNostalgia(ServerPlayer p) {
        ServerLevel level = p.server.getLevel(ModDimensions.NOSTALGIA);
        if (level != null) {
            p.teleportTo(level, SPAWN_X + 0.5D, 64.0D, SPAWN_Z + 0.5D, 0.0F, 0.0F);
        }
    }

    public static void enterBroken(ServerPlayer p, boolean randomSpot) {
        MinecraftServer server = p.server;
        ServerLevel level = server.getLevel(ModDimensions.BROKEN);
        if (level == null) {
            p.sendSystemMessage(Component.literal("[usedtobe] brokenmemories isn't loaded (is the mod's data pack enabled?)"));
            return;
        }
        int x = randomSpot ? p.getRandom().nextInt(4001) - 2000 : Mth.floor(p.getX());
        int z = randomSpot ? p.getRandom().nextInt(4001) - 2000 : Mth.floor(p.getZ());
        int tx = Math.floorDiv(x, MazeFeature.CELL) * MazeFeature.CELL + 1; // centre of a maze cell
        int tz = Math.floorDiv(z, MazeFeature.CELL) * MazeFeature.CELL + 1;

        // punch a shaft through the ceiling so you fall in from above
        BlockState air = Blocks.AIR.defaultBlockState();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                for (int y = MazeFeature.FLOOR + 3; y <= MazeFeature.TOP; y++) {
                    level.setBlock(new BlockPos(tx + dx, y, tz + dz), air, 2);
                }
            }
        }

        CompoundTag d = data(p);
        boolean fresh = !d.getBoolean("brokenInit");
        d.putInt("phase", PHASE_BROKEN);
        d.putInt("ticks", 0);
        d.putInt("nextMsg", 400);
        d.putInt("nextHint", 3000);
        d.putBoolean("collapsing", false);
        d.putBoolean("entering", false);

        lockRules(server);
        removeCompass(p);
        p.removeEffect(ModEffects.THE_ROT.get());
        p.teleportTo(level, tx + 0.5D, MazeFeature.TOP + 4, tz + 0.5D, p.getYRot(), 0.0F);
        p.fallDistance = 0.0F;
        p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0, false, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 140, 0, false, false, false));
        titles(p, "brokenmemories", "you shouldn't have let it rot");

        if (fresh) {
            d.putBoolean("brokenInit", true);
            d.putInt("hearts", 0);
            placeNextHeart(level, p, d);
        } else if (d.contains("heartX")) {
            giveCompass(p, new BlockPos(d.getInt("heartX"), MazeFeature.FLOOR + 1, d.getInt("heartZ")), ModDimensions.BROKEN);
        }
    }

    /** The ending: wake up. */
    private static void finishGame(ServerPlayer p) {
        MinecraftServer server = p.server;
        removeCompass(p);
        CompoundTag d = data(p);
        wipe(d);
        d.putInt("phase", PHASE_DONE);
        p.removeAllEffects();
        unlockRules(server);

        ServerLevel ow = server.overworld();
        BlockPos sp = ow.getSharedSpawnPos();
        ow.getChunk(sp.getX() >> 4, sp.getZ() >> 4);
        int y = ow.getHeight(Heightmap.Types.MOTION_BLOCKING, sp.getX(), sp.getZ());
        p.teleportTo(ow, sp.getX() + 0.5D, y, sp.getZ() + 0.5D, p.getYRot(), 0.0F);

        ItemStack page = lastPage();
        if (!p.getInventory().add(page)) {
            p.drop(page, false);
        }
        titles(p, "you remembered", "it used to be yours");
    }

    public static void reset(ServerPlayer p) {
        MinecraftServer server = p.server;
        removeCompass(p);
        CompoundTag d = data(p);
        wipe(d);
        d.putInt("phase", PHASE_DONE);
        p.removeEffect(ModEffects.THE_ROT.get());
        unlockRules(server);

        ServerLevel ow = server.overworld();
        BlockPos sp = ow.getSharedSpawnPos();
        ow.getChunk(sp.getX() >> 4, sp.getZ() >> 4);
        int y = ow.getHeight(Heightmap.Types.MOTION_BLOCKING, sp.getX(), sp.getZ());
        p.teleportTo(ow, sp.getX() + 0.5D, y, sp.getZ() + 0.5D, p.getYRot(), 0.0F);
    }

    private static void lockRules(MinecraftServer server) {
        GameRules rules = server.getGameRules();
        rules.getRule(GameRules.RULE_DAYLIGHT).set(false, server);
        rules.getRule(GameRules.RULE_WEATHER_CYCLE).set(false, server);
    }

    private static void unlockRules(MinecraftServer server) {
        GameRules rules = server.getGameRules();
        rules.getRule(GameRules.RULE_DAYLIGHT).set(true, server);
        rules.getRule(GameRules.RULE_WEATHER_CYCLE).set(true, server);
        server.overworld().setDayTime(1000L);
    }

    // ================================================================ act 1: nostalgia

    /** 0..1: how far gone the world is. Notebooks drive it; the clock alone can only drag it about halfway. */
    private static double progress(CompoundTag d, int ticks, int total, int need, boolean finale) {
        if (finale) {
            return 1.0D;
        }
        double found = Math.min(1.0D, d.getInt("foundCount") / (double) need);
        double clock = Math.min(1.0D, ticks / (double) total) * 0.5D;
        double prog = Math.max(found, clock);
        int force = d.getInt("forceStage");
        if (force > 0) {
            prog = Math.max(prog, STAGE_START[Math.min(force, STAGE_START.length - 1)]);
        }
        return prog;
    }

    private static int stageFor(double prog, boolean finale) {
        if (finale) {
            return 4;
        }
        int stage = 0;
        for (int i = 0; i < STAGE_START.length; i++) {
            if (prog >= STAGE_START[i]) {
                stage = i;
            }
        }
        return stage;
    }

    private static void tickNostalgia(ServerPlayer p, CompoundTag d) {
        ServerLevel level = p.serverLevel();
        if (level.dimension() != ModDimensions.NOSTALGIA) {
            if (p.tickCount > 60 && p.tickCount % 20 == 0) {
                defer(() -> returnToNostalgia(p)); // died or wandered off: the world wants you back
            }
            return;
        }

        int ticks = d.getInt("ticks") + 1;
        d.putInt("ticks", ticks);
        if (d.getBoolean("collapsing")) {
            tickCollapse(p, d, level);
            return;
        }

        int need = Config.MEMORIES_REQUIRED.get();
        int total = Config.COLLAPSE_MINUTES.get() * 1200;

        if (ticks == 160 && !d.getBoolean("introSent")) {
            d.putBoolean("introSent", true);
            say(p, "there's a notebook in the chest. you always kept one in the chest.", ChatFormatting.GRAY);
        }
        if (ticks % 10 == 0 && !d.getBoolean("finale")) {
            scanMemories(p, d, level);
        }

        // after a notebook, the world gives you a minute before it shows you the next one
        int pending = d.getInt("sitePending");
        if (pending > 0 && ticks >= pending && !d.getBoolean("finale")) {
            d.putInt("sitePending", 0);
            placeNextSite(p, d, level);
        }

        boolean finale = d.getBoolean("finale");
        if (!finale && (d.getInt("foundCount") >= need || ticks >= total)) {
            beginFinale(p, d);
            finale = true;
        }

        double prog = progress(d, ticks, total, need, finale);
        int stage = stageFor(prog, finale);

        int shown = d.getInt("stageShown");
        if (stage > shown) {
            d.putInt("stageShown", stage);
            for (int s = shown + 1; s <= stage; s++) {
                onStageReached(p, d, level, s);
            }
        }

        if (ticks % 20 == 0) {
            // the client reads the stage back out of this hidden effect (fog, music, shake)
            p.addEffect(new MobEffectInstance(ModEffects.THE_ROT.get(), 60, stage, false, false, false));
            // slide toward the target time of day instead of snapping
            long target = (long) (6000.0D + prog * 11500.0D);
            long cur = Math.min(target, d.getLong("dayT") + 120L);
            d.putLong("dayT", cur);
            p.server.overworld().setDayTime(cur);
        }

        // the echo standing at the next base, visible once you're in range
        if (d.contains("siteId", Tag.TAG_STRING) && !d.getBoolean("echoPlaced")) {
            double dx = d.getInt("siteX") + 0.5D - p.getX();
            double dz = d.getInt("siteZ") + 0.5D - p.getZ();
            if (dx * dx + dz * dz < 70.0D * 70.0D) {
                int[] size = NostalgiaFeature.siteSize(d.getString("siteId"));
                spawnEcho(level, d.getInt("siteOx") + size[0] / 2.0D + 0.5D, 64.0D, d.getInt("siteOz") - 2.5D, stage >= 3);
                d.putBoolean("echoPlaced", true);
            }
        }

        // if you're wandering, remind you where to go
        if (d.contains("siteId", Tag.TAG_STRING) && !finale && ticks >= d.getInt("nextHint")) {
            hint(p, d.getInt("siteX"), d.getInt("siteZ"), "the next notebook is %s, to the %s (about %d blocks). follow the needle.", ChatFormatting.GRAY);
            d.putInt("nextHint", ticks + 2400);
        }

        if (stage >= 1 && ticks >= d.getInt("nextMsg")) {
            String[] pool = stage == 1 ? STAGE1 : stage == 2 ? STAGE2 : stage == 3 ? STAGE3 : STAGE4;
            whisper(p, d, pool, stage >= 3 ? ChatFormatting.DARK_RED : ChatFormatting.GRAY);
            int base = stage == 1 ? 1400 : stage == 2 ? 900 : stage == 3 ? 560 : 280;
            d.putInt("nextMsg", ticks + base + p.getRandom().nextInt(base / 2 + 1));
        }

        if (stage >= 2 && ticks % 900 == 0) {
            spawnEchoNear(level, p, stage >= 3);
        }
        if (stage >= 2 && ticks % 20 == 0) {
            rot(level, p, stage);
        }
        if (stage == 3 && ticks % 240 == 0) {
            crackNear(level, p, 1);
        }
        if (stage >= 4 && ticks % 100 == 0) {
            crackNear(level, p, 2);
        }

        if (finale) {
            int ft = d.getInt("finaleTicks") + 1;
            d.putInt("finaleTicks", ft);
            if (ft % 20 == 0) {
                crackNear(level, p, 2);
            }
            if (ft >= 600) {
                startCollapse(p, d, level);
            }
        }
    }

    /** One-off set pieces when the decay crosses into a new chapter. */
    private static void onStageReached(ServerPlayer p, CompoundTag d, ServerLevel level, int stage) {
        if (stage < 1 || stage >= CHAPTER_COUNT) {
            return;
        }
        titles(p, CHAPTER[stage], CHAPTER_SUB[stage]);
        p.playNotifySound(ModSounds.vanilla("ambient.cave"), SoundSource.AMBIENT, 1.0F, 0.5F);
        switch (stage) {
            case 1 -> spawnEchoNear(level, p, false);
            case 2 -> snuffTorches(level, p, 22);
            case 3 -> vanishAnimals(level, p);
            case 4 -> crackNear(level, p, 4);
            default -> { }
        }
    }

    private static void snuffTorches(ServerLevel level, ServerPlayer p, int radius) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int cx = Mth.floor(p.getX());
        int cz = Mth.floor(p.getZ());
        int out = 0;
        for (int x = cx - radius; x <= cx + radius; x++) {
            for (int z = cz - radius; z <= cz + radius; z++) {
                pos.set(x, 70, z);
                if (!level.hasChunkAt(pos)) {
                    continue;
                }
                for (int y = 56; y <= 96; y++) {
                    pos.set(x, y, z);
                    BlockState s = level.getBlockState(pos);
                    if (s.is(Blocks.TORCH) || s.is(Blocks.WALL_TORCH)) {
                        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                        out++;
                    }
                }
            }
        }
        if (out > 0) {
            level.playSound(null, p.blockPosition(), ModSounds.vanilla("block.fire.extinguish"), SoundSource.AMBIENT, 0.8F, 0.6F);
            say(p, "the lights are going out, one at a time.", ChatFormatting.GRAY);
        }
    }

    private static void vanishAnimals(ServerLevel level, ServerPlayer p) {
        List<Animal> animals = level.getEntitiesOfClass(Animal.class, p.getBoundingBox().inflate(80.0D));
        for (Animal a : animals) {
            level.sendParticles(ParticleTypes.ASH, a.getX(), a.getY() + 0.5D, a.getZ(), 8, 0.3D, 0.3D, 0.3D, 0.02D);
            a.discard();
        }
        if (!animals.isEmpty()) {
            say(p, "where did everyone go?", ChatFormatting.DARK_RED);
        }
    }

    /** Looks through the player's inventory for notebooks they haven't been credited for yet. */
    private static void scanMemories(ServerPlayer p, CompoundTag d, ServerLevel level) {
        if (!d.contains("found", Tag.TAG_COMPOUND)) {
            d.put("found", new CompoundTag());
        }
        CompoundTag found = d.getCompound("found");
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.isEmpty() || !s.hasTag()) {
                continue;
            }
            CompoundTag t = s.getTag();
            if (t == null || !t.contains("usedtobe_memory", Tag.TAG_STRING)) {
                continue;
            }
            String id = t.getString("usedtobe_memory");
            if (!found.contains(id)) {
                found.putBoolean(id, true);
                onMemoryFound(p, d, level, id);
            }
        }
    }

    private static void onMemoryFound(ServerPlayer p, CompoundTag d, ServerLevel level, String id) {
        int n = d.getInt("foundCount") + 1;
        d.putInt("foundCount", n);
        int need = Config.MEMORIES_REQUIRED.get();
        p.displayClientMessage(Component.literal("remembered (" + n + "/" + need + ")")
                .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), true);
        p.playNotifySound(ModSounds.vanilla("block.amethyst_block.chime"), SoundSource.AMBIENT, 1.0F, 0.6F);
        if (n < need) {
            whisper(p, d, FOUND, ChatFormatting.GRAY);
            String current = d.getString("siteId");
            if (current.isEmpty() || current.equals(id)) {
                // that base is done with. the needle goes quiet until the world is ready to show you the next one
                d.remove("siteId");
                removeCompass(p);
                int delay = n == 1 ? 100 : Config.NOTEBOOK_DELAY.get() * 20;
                d.putInt("sitePending", d.getInt("ticks") + Math.max(1, delay));
            }
        }
    }

    /** Debug/testing: credit the next unfound notebook. */
    private static void rememberNext(ServerPlayer p) {
        if (data(p).getInt("phase") != PHASE_NOSTALGIA) {
            beginNostalgia(p);
        }
        CompoundTag d = data(p);
        if (!d.contains("found", Tag.TAG_COMPOUND)) {
            d.put("found", new CompoundTag());
        }
        CompoundTag found = d.getCompound("found");
        String next = null;
        if (!found.contains("first")) {
            next = "first";
        } else {
            for (String id : NostalgiaFeature.NOTEBOOK_IDS) {
                if (!found.contains(id)) {
                    next = id;
                    break;
                }
            }
        }
        if (next != null) {
            found.putBoolean(next, true);
            onMemoryFound(p, d, p.serverLevel(), next);
        }
    }

    /** Builds the next notebook base out in the fog, on the flattest ground it can find, and points the compass at it. */
    private static void placeNextSite(ServerPlayer p, CompoundTag d, ServerLevel level) {
        CompoundTag found = d.getCompound("found");
        String id = null;
        for (String candidate : NostalgiaFeature.NOTEBOOK_IDS) { // story order: silly first, heartbreaking last
            if (!found.contains(candidate)) {
                id = candidate;
                break;
            }
        }
        if (id == null) {
            return;
        }
        RandomSource r = level.random;
        long seed = level.getSeed();
        int[] size = NostalgiaFeature.siteSize(id);
        int stage = d.getInt("stageShown");
        double base = Config.SITE_DISTANCE.get() + stage * 12.0D;

        int x = Mth.floor(p.getX() + base);
        int z = Mth.floor(p.getZ());
        int best = Integer.MAX_VALUE;
        for (int i = 0; i < 48; i++) {
            double ang = r.nextDouble() * Math.PI * 2.0D;
            double dist = base + r.nextDouble() * 55.0D;
            int cx = Mth.floor(p.getX() + Math.cos(ang) * dist);
            int cz = Mth.floor(p.getZ() + Math.sin(ang) * dist);
            int score = Terrain.roughness(seed, cx - 2, cz - 2, cx + size[0] + 2, cz + size[1] + 2);
            if (score < best) {
                best = score;
                x = cx;
                z = cz;
                if (score == 0) {
                    break;
                }
            }
        }

        NostalgiaFeature.clearArea(level, x - 1, z - 1, x + size[0], z + size[1]);
        NostalgiaFeature.buildSite(level, r, id, x, z);

        int cx = x + size[0] / 2;
        int cz = z + size[1] / 2;
        d.putString("siteId", id);
        d.putInt("siteOx", x);
        d.putInt("siteOz", z);
        d.putInt("siteX", cx);
        d.putInt("siteZ", cz);
        d.putBoolean("echoPlaced", false);
        d.putInt("nextHint", d.getInt("ticks") + 2400);
        giveCompass(p, new BlockPos(cx, NostalgiaFeature.GROUND, cz), ModDimensions.NOSTALGIA);
        hint(p, cx, cz, "i left another notebook %s, to the %s (about %d blocks). the needle knows.", ChatFormatting.GRAY);
    }

    private static void beginFinale(ServerPlayer p, CompoundTag d) {
        d.putBoolean("finale", true);
        d.putInt("finaleTicks", 0);
        d.putInt("sitePending", 0);
        removeCompass(p);
        p.sendSystemMessage(Component.literal("you remembered all of it.").withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
        p.sendSystemMessage(Component.literal("that's too much. i can't hold it anymore.").withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC));
        p.playNotifySound(ModSounds.vanilla("entity.warden.heartbeat"), SoundSource.AMBIENT, 1.0F, 0.5F);
    }

    private static void startCollapse(ServerPlayer p, CompoundTag d, ServerLevel level) {
        d.putBoolean("collapsing", true);
        d.putInt("collapseTicks", 0);
        BlockPos pos = p.blockPosition();
        openHole(level, pos.getX(), pos.getZ(), pos.getY());
        for (int i = 0; i < 8; i++) {
            startCrack(level, pos.getX() + 0.5D, pos.getZ() + 0.5D, i * (Math.PI / 4.0D), 14);
        }
        p.sendSystemMessage(Component.literal("you'll never get this back, you know?").withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC));
        level.playSound(null, pos, ModSounds.vanilla("entity.generic.explode"), SoundSource.AMBIENT, 0.6F, 0.5F);
        level.playSound(null, pos, ModSounds.vanilla("block.sculk_shrieker.shriek"), SoundSource.AMBIENT, 0.8F, 0.5F);
    }

    private static void tickCollapse(ServerPlayer p, CompoundTag d, ServerLevel level) {
        int c = d.getInt("collapseTicks") + 1;
        d.putInt("collapseTicks", c);
        if (c % 10 == 0) {
            level.playSound(null, p.blockPosition(), ModSounds.vanilla("block.gravel.break"), SoundSource.AMBIENT, 0.8F, 0.5F);
        }
        if (!d.getBoolean("entering") && (p.getY() < 24.0D || c >= 100)) {
            d.putBoolean("entering", true);
            defer(() -> enterBroken(p, false));
        }
    }

    private static void openHole(ServerLevel level, int cx, int cz, int topY) {
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                if (dx * dx + dz * dz > 5) {
                    continue;
                }
                for (int y = topY; y >= 0; y--) {
                    level.setBlock(pos.set(cx + dx, y, cz + dz), air, 2);
                }
            }
        }
    }

    /** True for things you can walk straight through: grass tufts, flowers, torches. */
    private static boolean isSoft(ServerLevel level, BlockPos pos, BlockState s) {
        return s.getFluidState().isEmpty() && s.getCollisionShape(level, pos).isEmpty();
    }

    /** Slowly eats the world around the player. */
    private static void rot(ServerLevel level, ServerPlayer p, int stage) {
        RandomSource r = level.random;
        long seed = level.getSeed();
        int samples = 8 + stage * 6;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int i = 0; i < samples; i++) {
            int x = Mth.floor(p.getX()) + r.nextInt(49) - 24;
            int z = Mth.floor(p.getZ()) + r.nextInt(49) - 24;
            pos.set(x, 70, z);
            if (!level.hasChunkAt(pos)) {
                continue;
            }
            for (int y = Math.min(110, Terrain.height(seed, x, z) + 16); y >= 52; y--) {
                pos.set(x, y, z);
                BlockState s = level.getBlockState(pos);
                if (s.isAir()) {
                    continue;
                }
                if (!s.getFluidState().isEmpty()) {
                    break; // lakes stay as they are
                }
                if (isSoft(level, pos, s)) {
                    if (stage >= 2 && r.nextFloat() < 0.5F) {
                        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 2); // the flowers go first
                    }
                    continue;
                }
                if (s.is(ModBlocks.OLD_GRASS.get())) {
                    if (r.nextFloat() < 0.7F) {
                        level.setBlock(pos, ModBlocks.ROTTED_GRASS.get().defaultBlockState(), 2);
                    }
                } else if (stage >= 3 && (s.is(ModBlocks.ROTTED_GRASS.get()) || s.is(ModBlocks.OLD_PATH.get())) && r.nextFloat() < 0.3F) {
                    level.setBlock(pos, ModBlocks.CRACKED_EARTH.get().defaultBlockState(), 2);
                } else if (stage >= 3 && isMemory(s) && r.nextFloat() < (stage == 3 ? 0.12F : 0.45F)) {
                    level.sendParticles(ParticleTypes.ASH, x + 0.5D, y + 0.5D, z + 0.5D, 4, 0.3D, 0.3D, 0.3D, 0.02D);
                    level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                }
                break;
            }
        }
    }

    private static boolean isMemory(BlockState s) {
        Block b = s.getBlock();
        // chests are left alone on purpose: the notebooks must survive the decay
        return b == ModBlocks.OLD_DIRT.get() || b == ModBlocks.OLD_COBBLE.get() || b == ModBlocks.OLD_PLANKS.get()
                || b == ModBlocks.OLD_LOG.get() || b == ModBlocks.OLD_LEAVES.get()
                || b == Blocks.TORCH || b == Blocks.CRAFTING_TABLE || b == Blocks.FURNACE
                || b == Blocks.OAK_DOOR || b == Blocks.GLASS || b == Blocks.OBSIDIAN
                || b == Blocks.OAK_FENCE || b == Blocks.CHAIN || b == Blocks.OAK_SLAB || b == Blocks.OAK_STAIRS
                || b == Blocks.WHITE_WOOL || b == Blocks.RED_WOOL || b == Blocks.BLUE_WOOL || b == Blocks.YELLOW_WOOL;
    }

    // ================================================================ cracks

    private static void crackNear(ServerLevel level, ServerPlayer p, int count) {
        RandomSource r = level.random;
        for (int i = 0; i < count; i++) {
            double ang = r.nextDouble() * Math.PI * 2.0D;
            double dist = 5.0D + r.nextDouble() * 13.0D;
            startCrack(level, p.getX() + Math.cos(ang) * dist, p.getZ() + Math.sin(ang) * dist,
                    r.nextDouble() * Math.PI * 2.0D, 10 + r.nextInt(14));
        }
    }

    private static void startCrack(ServerLevel level, double x, double z, double angle, int length) {
        CRACKS.add(new Crack(level, x, z, angle, length));
    }

    private static final class Crack {
        private final ServerLevel level;
        private final long seed;
        private double x;
        private double z;
        private double angle;
        private int remaining;
        private int steps;

        Crack(ServerLevel level, double x, double z, double angle, int length) {
            this.level = level;
            this.seed = level.getSeed();
            this.x = x;
            this.z = z;
            this.angle = angle;
            this.remaining = length;
        }

        boolean tick() {
            for (int i = 0; i < 2 && this.remaining > 0; i++) {
                this.angle += (this.level.random.nextDouble() - 0.5D) * 0.6D;
                this.x += Math.cos(this.angle);
                this.z += Math.sin(this.angle);
                carve(Mth.floor(this.x), Mth.floor(this.z));
                if (this.level.random.nextInt(5) == 0) {
                    carve(Mth.floor(this.x + Math.sin(this.angle)), Mth.floor(this.z - Math.cos(this.angle)));
                }
                this.remaining--;
                this.steps++;
            }
            return this.remaining > 0;
        }

        private void carve(int bx, int bz) {
            BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos(bx, 63, bz);
            if (!this.level.hasChunkAt(pos)) {
                return;
            }
            int surface = Terrain.height(this.seed, bx, bz);
            int top = -1;
            for (int y = Math.min(110, surface + 3); y >= 50; y--) {
                pos.setY(y);
                BlockState s = this.level.getBlockState(pos);
                if (s.isAir()) {
                    continue;
                }
                if (!s.getFluidState().isEmpty()) {
                    return; // never crack a lake
                }
                if (s.getCollisionShape(this.level, pos).isEmpty()) {
                    continue; // grass, flowers
                }
                top = y;
                break;
            }
            if (top < 50 || top > surface) {
                return; // don't crack through buildings
            }
            int depth = 3 + this.level.random.nextInt(2);
            BlockState air = Blocks.AIR.defaultBlockState();
            for (int y = top; y > top - depth && y >= 1; y--) {
                pos.setY(y);
                // never swallow a buried chest (the treasure notebook lives 3 deep)
                if (this.level.getBlockState(pos).is(Blocks.CHEST)) {
                    return;
                }
                this.level.setBlock(pos, air, 2);
            }
            for (Direction dir : Direction.Plane.HORIZONTAL) {
                BlockPos n = new BlockPos(bx, top, bz).relative(dir);
                BlockState ns = this.level.getBlockState(n);
                if (ns.is(ModBlocks.OLD_GRASS.get()) || ns.is(ModBlocks.ROTTED_GRASS.get()) || ns.is(ModBlocks.OLD_PATH.get())) {
                    this.level.setBlock(n, ModBlocks.CRACKED_EARTH.get().defaultBlockState(), 2);
                }
            }
            if (this.steps % 5 == 0) {
                this.level.playSound(null, bx + 0.5D, top, bz + 0.5D, ModSounds.vanilla("block.gravel.break"),
                        SoundSource.AMBIENT, 0.7F, 0.5F);
            }
        }
    }

    // ================================================================ echoes

    private static void spawnEcho(ServerLevel level, double x, double y, double z, boolean creeping) {
        if (!level.hasChunkAt(BlockPos.containing(x, y, z))) {
            return;
        }
        EchoEntity e = ModEntities.ECHO.get().create(level);
        if (e == null) {
            return;
        }
        e.moveTo(x, y, z, 0.0F, 0.0F);
        e.setCreeping(creeping);
        level.addFreshEntity(e);
    }

    private static void spawnEchoNear(ServerLevel level, ServerPlayer p, boolean creeping) {
        if (!level.getEntitiesOfClass(EchoEntity.class, p.getBoundingBox().inflate(90.0D)).isEmpty()) {
            return;
        }
        double ang = level.random.nextDouble() * Math.PI * 2.0D;
        double dist = 26.0D + level.random.nextDouble() * 10.0D;
        int ex = Mth.floor(p.getX() + Math.cos(ang) * dist);
        int ez = Mth.floor(p.getZ() + Math.sin(ang) * dist);
        int eh = Terrain.height(level.getSeed(), ex, ez);
        if (Terrain.isWater(eh)) {
            return;
        }
        spawnEcho(level, ex + 0.5D, eh + 1, ez + 0.5D, creeping);
    }

    // ================================================================ act 2: brokenmemories

    private static void tickBroken(ServerPlayer p, CompoundTag d) {
        ServerLevel level = p.serverLevel();
        if (level.dimension() != ModDimensions.BROKEN) {
            if (p.tickCount > 40 && p.tickCount % 20 == 0) {
                defer(() -> enterBroken(p, true)); // you don't get to leave
            }
            return;
        }

        int ticks = d.getInt("ticks") + 1;
        d.putInt("ticks", ticks);

        if (ticks % 20 == 0) {
            // the client reads how many hearts you've touched out of this hidden effect (heartbeat speed, fog, shake)
            p.addEffect(new MobEffectInstance(ModEffects.THE_ROT.get(), 60, Math.min(d.getInt("hearts"), 7), false, false, false));
        }

        int end = d.getInt("endTimer");
        if (end > 0) {
            tickEnding(p, d, level, end);
            return;
        }

        if (ticks > 300 && ticks % 20 == 0) {
            manageParasites(level, p, d, ticks);
        }
        if (ticks >= d.getInt("nextMsg")) {
            whisper(p, d, BROKEN, ChatFormatting.DARK_RED);
            d.putInt("nextMsg", ticks + 700 + p.getRandom().nextInt(700));
        }
        if (d.contains("heartX") && ticks >= d.getInt("nextHint")) {
            hint(p, d.getInt("heartX"), d.getInt("heartZ"), "it's still beating %s, to the %s (about %d blocks).", ChatFormatting.DARK_RED);
            d.putInt("nextHint", ticks + 3000);
        }
    }

    private static void placeNextHeart(ServerLevel level, ServerPlayer p, CompoundTag d) {
        RandomSource r = level.random;
        long seed = level.getSeed();
        int taken = d.getInt("hearts");
        int want = HEART_ZONES[Math.min(taken, HEART_ZONES.length - 1)];

        int hx = 0;
        int hz = 0;
        for (int i = 0; i < 48; i++) {
            double ang = r.nextDouble() * Math.PI * 2.0D;
            double dist = 60.0D + taken * 18.0D + r.nextDouble() * 35.0D; // each one is further than the last
            int x = Mth.floor(p.getX() + Math.cos(ang) * dist);
            int z = Mth.floor(p.getZ() + Math.sin(ang) * dist);
            hx = Math.floorDiv(x, MazeFeature.CELL) * MazeFeature.CELL + 1; // centre of an always-open cell
            hz = Math.floorDiv(z, MazeFeature.CELL) * MazeFeature.CELL + 1;
            if (MazeShape.zoneAt(seed, hx, hz) == want) {
                break;
            }
        }
        int y = MazeFeature.FLOOR + 1;

        buildAltar(level, hx, hz);
        level.setBlock(new BlockPos(hx, y, hz), ModBlocks.MEMORY_HEART.get().defaultBlockState(), 2);
        int required = Config.HEARTS_REQUIRED.get();
        int n = taken + 1 >= required ? 5 : Math.min(taken + 1, 4);
        NostalgiaFeature.chestAt(level, r, hx + 1, y, hz - 1, Direction.SOUTH, NostalgiaFeature.lootId("book_corrupt_" + n));

        d.putInt("heartX", hx);
        d.putInt("heartZ", hz);
        d.putInt("nextHint", d.getInt("ticks") + 3000);
        giveCompass(p, new BlockPos(hx, y, hz), ModDimensions.BROKEN);
        hint(p, hx, hz, "it's still beating %s, to the %s (about %d blocks).", ChatFormatting.DARK_RED);
    }

    /** A little ring of pale floor with four glowing corners, so a heart is something you can find. */
    private static void buildAltar(ServerLevel level, int hx, int hz) {
        BlockState air = Blocks.AIR.defaultBlockState();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                boolean corner = dx != 0 && dz != 0;
                level.setBlock(new BlockPos(hx + dx, MazeFeature.FLOOR, hz + dz),
                        corner ? ModBlocks.FLESH_GLOW.get().defaultBlockState() : ModBlocks.SCAR_TISSUE.get().defaultBlockState(), 2);
                for (int y = MazeFeature.FLOOR + 1; y <= MazeFeature.FLOOR + 3; y++) {
                    level.setBlock(new BlockPos(hx + dx, y, hz + dz), air, 2);
                }
            }
        }
    }

    /** Called by the heart block. */
    public static void onHeartTouched(ServerPlayer p, BlockPos pos) {
        CompoundTag d = data(p);
        ServerLevel level = p.serverLevel();
        if (d.getInt("phase") != PHASE_BROKEN || d.getInt("endTimer") > 0 || level.dimension() != ModDimensions.BROKEN) {
            return;
        }
        level.setBlock(pos, ModBlocks.FLESH_GLOW.get().defaultBlockState(), 3); // it goes still
        int hearts = d.getInt("hearts") + 1;
        d.putInt("hearts", hearts);

        level.sendParticles(ParticleTypes.CRIMSON_SPORE, pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, 60, 0.6D, 0.6D, 0.6D, 0.05D);
        level.playSound(null, pos, ModSounds.vanilla("entity.warden.heartbeat"), SoundSource.BLOCKS, 1.5F, 0.4F);
        level.playSound(null, pos, ModSounds.vanilla("entity.generic.explode"), SoundSource.BLOCKS, 0.5F, 0.4F);
        p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 60 + hearts * 30, 0, false, false, false));

        if (hearts >= Config.HEARTS_REQUIRED.get()) {
            d.putInt("endTimer", 200);
            removeCompass(p);
        } else {
            int line = Math.min(hearts - 1, HEART_LINES.length - 1);
            p.sendSystemMessage(Component.literal(HEART_LINES[line]).withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC));
            p.playNotifySound(ModSounds.vanilla("ambient.cave"), SoundSource.AMBIENT, 0.7F, 0.5F);
            int answers = Math.min(1 + hearts, 5);
            for (int i = 0; i < answers; i++) { // the walls answer, harder every time
                spawnParasite(level, p);
            }
            placeNextHeart(level, p, d);
        }
    }

    private static void tickEnding(ServerPlayer p, CompoundTag d, ServerLevel level, int end) {
        d.putInt("endTimer", end - 1);
        if (end == 199) {
            say(p, "you remembered all of it.", ChatFormatting.GRAY);
        }
        if (end == 150) {
            for (ParasiteEntity e : level.getEntitiesOfClass(ParasiteEntity.class, p.getBoundingBox().inflate(96.0D))) {
                e.discard();
            }
            say(p, "it doesn't hurt anymore.", ChatFormatting.GRAY);
        }
        if (end == 100) {
            p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 90, 0, false, false, false));
            say(p, "go on. i'll be here.", ChatFormatting.GRAY);
        }
        if (end == 1) {
            finishGame(p);
        }
    }

    private static void manageParasites(ServerLevel level, ServerPlayer p, CompoundTag d, int ticks) {
        List<ParasiteEntity> near = level.getEntitiesOfClass(ParasiteEntity.class, p.getBoundingBox().inflate(48.0D));
        int cap = Math.min(Config.PARASITE_CAP.get(), 1 + ticks / 3600 + d.getInt("hearts")); // worse each heart
        if (near.size() < cap && p.getRandom().nextInt(4) == 0) {
            spawnParasite(level, p);
        }
    }

    private static void spawnParasite(ServerLevel level, ServerPlayer p) {
        RandomSource r = level.random;
        for (int i = 0; i < 16; i++) {
            double ang = r.nextDouble() * Math.PI * 2.0D;
            double dist = 14.0D + r.nextDouble() * 14.0D;
            int x = Mth.floor(p.getX() + Math.cos(ang) * dist);
            int z = Mth.floor(p.getZ() + Math.sin(ang) * dist);
            int y = MazeFeature.FLOOR + 1 + r.nextInt(MazeFeature.HEIGHT);
            BlockPos pos = new BlockPos(x, y, z);
            if (!level.hasChunkAt(pos) || !level.getBlockState(pos).isSuffocating(level, pos)) {
                continue; // only spawn buried inside a wall
            }
            ParasiteEntity e = ModEntities.PARASITE.get().create(level);
            if (e == null) {
                return;
            }
            e.moveTo(x + 0.5D, y, z + 0.5D, r.nextFloat() * 360.0F, 0.0F);
            level.addFreshEntity(e);
            return;
        }
    }

    // ================================================================ compass + hints

    private static void giveCompass(ServerPlayer p, BlockPos target, ResourceKey<Level> dim) {
        removeCompass(p);
        ItemStack compass = new ItemStack(Items.COMPASS);
        CompoundTag t = compass.getOrCreateTag();
        t.put("LodestonePos", NbtUtils.writeBlockPos(target));
        t.putString("LodestoneDimension", dim.location().toString());
        t.putBoolean("LodestoneTracked", false); // no lodestone block needed
        t.putBoolean("usedtobe_compass", true);
        compass.setHoverName(Component.literal("the way back").withStyle(ChatFormatting.GRAY));
        if (!p.getInventory().add(compass)) {
            p.drop(compass, false);
        }
    }

    private static void removeCompass(ServerPlayer p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && s.hasTag()) {
                CompoundTag t = s.getTag();
                if (t != null && t.getBoolean("usedtobe_compass")) {
                    inv.setItem(i, ItemStack.EMPTY);
                }
            }
        }
    }

    private static void hint(ServerPlayer p, int tx, int tz, String template, ChatFormatting colour) {
        double dx = tx + 0.5D - p.getX();
        double dz = tz + 0.5D - p.getZ();
        int dist = (int) Math.round(Math.sqrt(dx * dx + dz * dz));
        String near = dist < 20 ? "right here, almost" : dist < 50 ? "not far" : "far";
        String text = String.format(template, near, dirWord(dx, dz), Math.max(5, dist / 5 * 5));
        p.sendSystemMessage(Component.literal(text).withStyle(colour, ChatFormatting.ITALIC));
    }

    private static String dirWord(double dx, double dz) {
        String[] names = {"north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"};
        double ang = Math.toDegrees(Math.atan2(dx, -dz)); // 0 = north (-z), 90 = east (+x)
        return names[Math.floorMod((int) Math.round(ang / 45.0D), 8)];
    }

    // ================================================================ presentation

    private static void say(ServerPlayer p, String text, ChatFormatting colour) {
        p.sendSystemMessage(Component.literal(text).withStyle(colour, ChatFormatting.ITALIC));
    }

    private static void whisper(ServerPlayer p, CompoundTag d, String[] pool, ChatFormatting colour) {
        int last = d.getInt("lastMsg");
        int idx = p.getRandom().nextInt(pool.length);
        if (pool.length > 1 && idx == last) {
            idx = (idx + 1) % pool.length;
        }
        d.putInt("lastMsg", idx);
        String name = p.getGameProfile().getName();
        String raw = pool[idx];
        if (raw.equals("<<left>>")) {
            // looks exactly like the real thing
            p.sendSystemMessage(Component.translatable("multiplayer.player.left", name).withStyle(ChatFormatting.YELLOW));
        } else {
            p.sendSystemMessage(Component.literal(raw.replace("{name}", name)).withStyle(colour, ChatFormatting.ITALIC));
        }
        p.playNotifySound(ModSounds.vanilla("ambient.cave"), SoundSource.AMBIENT, 0.7F, 0.6F + p.getRandom().nextFloat() * 0.3F);
    }

    private static void titles(ServerPlayer p, String title, String subtitle) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(20, 80, 40));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(title).withStyle(ChatFormatting.GRAY)));
        p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(subtitle).withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC)));
    }

    private static ItemStack lastPage() {
        ItemStack book = new ItemStack(Items.WRITABLE_BOOK);
        ListTag pages = new ListTag();
        pages.add(StringTag.valueOf("you came back.\nthats all i wanted.\n\nyou grew up and i stayed ten.\nthats ok."));
        pages.add(StringTag.valueOf("go build something new.\nwrite it down this time.\n\n- me (age 10)\n- you"));
        book.getOrCreateTag().put("pages", pages);
        book.setHoverName(Component.literal("the last page"));
        return book;
    }
}
