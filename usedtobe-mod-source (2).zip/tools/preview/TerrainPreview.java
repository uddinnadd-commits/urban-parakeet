// Preview tool (not part of the mod). From the project root:
//   javac -d /tmp/pv src/main/java/com/usedtobe/world/{Noise,Terrain,MazeShape}.java tools/preview/TerrainPreview.java
//   java -cp /tmp/pv TerrainPreview <seed>     -> writes a .ppm top-down map in the current directory
import com.usedtobe.world.Terrain;
import java.io.*;

public class TerrainPreview {
    public static void main(String[] a) throws Exception {
        long seed = a.length > 0 ? Long.parseLong(a[0]) : 12345L;
        int cx = a.length > 1 ? Integer.parseInt(a[1]) : 0;
        int cz = a.length > 2 ? Integer.parseInt(a[2]) : 0;
        int N = 768;
        int[][] H = new int[N][N];
        long flat = 0, water = 0, high = 0, total = 0;
        int mx = 0, mn = 999;
        try (PrintStream out = new PrintStream(new FileOutputStream("terrain_" + seed + "_" + cx + "_" + cz + ".ppm"))) {
            out.print("P6\n" + N + " " + N + "\n255\n");
            for (int z = 0; z < N; z++) {
                for (int x = 0; x < N; x++) {
                    int wx = cx + x - N / 2, wz = cz + z - N / 2;
                    int h = Terrain.height(seed, wx, wz);
                    H[z][x] = h;
                    total++;
                    if (h == Terrain.BASE) flat++;
                    if (h < Terrain.WATER_Y) water++;
                    if (h > 70) high++;
                    mx = Math.max(mx, h); mn = Math.min(mn, h);
                }
            }
            for (int z = 0; z < N; z++) {
                for (int x = 0; x < N; x++) {
                    int wx = cx + x - N / 2, wz = cz + z - N / 2;
                    int h = H[z][x];
                    int r, g, b;
                    if (h < Terrain.WATER_Y) { int d = Math.min(10, Terrain.WATER_Y - h); r = 40 - d*2; g = 90 - d*4; b = 190 - d*8; }
                    else {
                        int hx = x > 0 ? H[z][x-1] : h, hz = z > 0 ? H[z-1][x] : h;
                        double shade = 1.0 + 0.12 * ((h - hx) + (h - hz));
                        double t = Math.max(0, Math.min(1, (h - 63) / 30.0));
                        r = (int) ((100 + 90 * t) * shade); g = (int) ((160 - 20 * t) * shade); b = (int) ((70 + 50 * t) * shade);
                        if (h == Terrain.BASE) { r = 120; g = 180; b = 80; }
                        if (Terrain.isPath(seed, wx, wz)) { r = 190; g = 160; b = 110; }
                        if (h >= 61 && h <= 62 && h != Terrain.BASE) { r = 215; g = 205; b = 150; }
                    }
                    if (Math.abs(wx - 8) < 2 && Math.abs(wz - 8) < 2) { r = 255; g = 0; b = 0; }
                    out.write(Math.max(0, Math.min(255, r))); out.write(Math.max(0, Math.min(255, g))); out.write(Math.max(0, Math.min(255, b)));
                }
            }
        }
        System.out.printf("seed %d: flat(63)=%.1f%% water=%.1f%% >70=%.1f%% min=%d max=%d%n", seed, 100.0*flat/total, 100.0*water/total, 100.0*high/total, mn, mx);
    }
}
